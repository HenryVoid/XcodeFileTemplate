import Foundation
import SwiftUI

enum ___FILEBASENAMEASIDENTIFIER___ {
    struct State: Equatable {
        
    }
    
    enum ViewAction: Equatable {
        case onAppear
    }
}
