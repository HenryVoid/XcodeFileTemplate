//___FILEHEADER___

import Foundation

enum ___FILEBASENAMEASIDENTIFIER___ {
    struct State: Equatable {
        
    }
    
    enum ViewAction: Equatable {
        case onLoad
        case onAppear
    }
}
